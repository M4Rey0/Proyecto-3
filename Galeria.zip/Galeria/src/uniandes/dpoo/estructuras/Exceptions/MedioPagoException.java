package uniandes.dpoo.estructuras.Exceptions;

public class MedioPagoException extends Exception {
    public MedioPagoException(String message) {
        super(message);
    }
}
